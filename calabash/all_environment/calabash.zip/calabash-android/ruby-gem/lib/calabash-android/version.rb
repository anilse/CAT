module Calabash
  module Android
    VERSION = "0.9.0"
  end
end
